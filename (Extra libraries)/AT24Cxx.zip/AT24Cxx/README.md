### AT24Cxx
I2C EEPROM Library for Arduino


```Arduino
#include <AT24Cxx.h>

void setup(){

}

void loop(){

}